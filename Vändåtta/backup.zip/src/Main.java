public class Main {
    public static void main(String[] args) {
        Cards card1 = new Cards();
        card1.colour = 0;
        card1.value = 2;

        Cards card2 = new Cards();
        card2.colour = 0;
        card2.value = 3;

        Cards card3 = new Cards();
        card3.colour = 0;
        card3.value = 4;

        Cards card4 = new Cards();
        card4.colour = 0;
        card4.value = 5;

        Cards card5 = new Cards();
        card5.colour = 0;
        card5.value = 6;

        Cards card6 = new Cards();
        card6.colour = 0;
        card6.value = 7;

        Cards card7 = new Cards();
        card7.colour = 0;
        card7.value = 8;

        Cards card8 = new Cards();
        card8.colour = 0;
        card8.value = 9;

        Cards card9 = new Cards();
        card9.colour = 0;
        card9.value = 10;

        Cards card10 = new Cards();
        card10.colour = 0;
        card10.value = 11;

        Cards card11 = new Cards();
        card11.colour = 0;
        card11.value = 12;

        Cards card12 = new Cards();
        card12.colour = 0;
        card12.value = 13;

        Cards card13 = new Cards();
        card13.colour = 0;
        card13.value = 14;


        Cards card14 = new Cards();
        card14.colour = 1;
        card14.value = 2;

        Cards card15 = new Cards();
        card15.colour = 1;
        card15.value = 3;

        Cards card16 = new Cards();
        card16.colour = 1;
        card16.value = 4;

        Cards card17 = new Cards();
        card17.colour = 1;
        card17.value = 5;

        Cards card18 = new Cards();
        card18.colour = 1;
        card18.value = 6;

        Cards card19 = new Cards();
        card19.colour = 1;
        card19.value = 7;

        Cards card20 = new Cards();
        card20.colour = 1;
        card20.value = 8;

        Cards card21 = new Cards();
        card21.colour = 1;
        card21.value = 9;

        Cards card22 = new Cards();
        card22.colour = 1;
        card22.value = 10;

        Cards card23 = new Cards();
        card23.colour = 1;
        card23.value = 11;

        Cards card24 = new Cards();
        card24.colour = 1;
        card24.value = 12;

        Cards card25 = new Cards();
        card25.colour = 1;
        card25.value = 13;

        Cards card26 = new Cards();
        card26.colour = 1;
        card26.value = 14;

        Cards card27 = new Cards();
        card27.colour = 2;
        card27.value = 2;

        Cards card28 = new Cards();
        card28.colour = 2;
        card28.value = 3;

        Cards card29 = new Cards();
        card29.colour = 2;
        card29.value = 4;

        Cards card30 = new Cards();
        card30.colour = 2;
        card30.value = 5;

        Cards card31 = new Cards();
        card31.colour = 2;
        card31.value = 6;

        Cards card32 = new Cards();
        card32.colour = 2;
        card32.value = 7;

        Cards card33 = new Cards();
        card33.colour = 2;
        card33.value = 8;

        Cards card34 = new Cards();
        card34.colour = 2;
        card34.value = 9;

        Cards card35 = new Cards();
        card35.colour = 2;
        card35.value = 10;

        Cards card36 = new Cards();
        card36.colour = 2;
        card36.value = 11;

        Cards card37 = new Cards();
        card37.colour = 2;
        card37.value = 12;

        Cards card38 = new Cards();
        card38.colour = 2;
        card38.value = 13;

        Cards card39 = new Cards();
        card39.colour = 2;
        card39.value = 14;

        Cards card40 = new Cards();
        card40.colour = 3;
        card40.value = 2;

        Cards card41 = new Cards();
        card41.colour = 3;
        card41.value = 3;

        Cards card42 = new Cards();
        card42.colour = 3;
        card42.value = 4;

        Cards card43 = new Cards();
        card43.colour = 3;
        card43.value = 5;

        Cards card44 = new Cards();
        card44.colour = 3;
        card44.value = 6;

        Cards card45 = new Cards();
        card45.colour = 3;
        card45.value = 7;

        Cards card46 = new Cards();
        card46.colour = 3;
        card46.value = 8;

        Cards card47 = new Cards();
        card47.colour = 3;
        card47.value = 9;

        Cards card48 = new Cards();
        card48.colour = 3;
        card48.value = 10;

        Cards card49 = new Cards();
        card49.colour = 3;
        card49.value = 11;

        Cards card50 = new Cards();
        card50.colour = 3;
        card50.value = 12;

        Cards card51 = new Cards();
        card51.colour = 3;
        card51.value = 13;

        Cards card52 = new Cards();
        card52.colour = 3;
        card52.value = 14;

        //Fråga efter spelarens namn
        //Dela två händer på 7 kort var
        //lägg ut ett första kort
        System.out.println(card50);
    }

}

import java.util.Arrays;
import java.util.Scanner;

public class TestKlass {
    public static void main(String[] arg) {

        //Initiera en kortlek
        Deck kort = new Deck();
        for (int colour = Cards.CLOVES, i = 0; colour <= Cards.SPADES; colour++) {
            for (int value = 2; value <= 14; value++, i++) {
                kort.deck[i] = new Cards();
                kort.deck[i].colour = colour;
                kort.deck[i].value = value;
                kort.antal++;

            }
        }
        //System.out.println(Arrays.toString(kort.deck));

        //Blanda korten
        kort.deck = kort.shuffle();

        //Dela ut 2 händer;
        //Spelare
        Player player= new Player();
        Player computer=new Player();
        player.hand = kort.deal();
        System.out.println("Dina kort:");
        Test2.print(player.hand);
        //Dator
        computer.hand = kort.deal();
        //System.out.println("Datorns kort:");
        //Test2.print(computer);
        //Vad är kvar i kortleken?
        //System.out.println(Arrays.toString(kort.deck));

        //Lägg ut ett första kort:
        Cards fromDeck = kort.pickCard();
        System.out.println("Startkortet är: " + fromDeck +
                ".\n Vad vill du lägga nu?");
        System.out.println("Ange kort med siffran 1-7,  från vänster räknat.");
        System.out.println("Om du inte kan lägga, ta upp ett kort från högen genom att skriva in Ta upp");

        //Spelarens tur:
       Cards topCard=Game.playersMove(player, fromDeck, kort);
        // TODO: 2019-12-03 Om top card är 8 får man lägga valfritt nytt kort
       //Datorns tur
        topCard=Game.computerMove(computer,topCard,kort);


    }
    //// TODO: 2019-12-02 Ta reda på spelarens namn.
    // TODO: 2019-12-02 skapa en binärfil med vinnare
    // TODO: 2019-12-02 Testa för fel


}


public class Player {
    String name;
    Deck hand;
}

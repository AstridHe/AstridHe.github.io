public class Test2 {
    public static void main(String[] args) {


    }
    public static void print(Deck a){

        for(int i=0; i<a.antal; i++) {
                System.out.println(a.deck[i]);
        }
    }
}

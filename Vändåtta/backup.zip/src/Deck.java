import org.w3c.dom.ls.LSOutput;

import javax.swing.*;

public class Deck {
    Cards[] deck = new Cards[52];
    int antal;

    public Cards[] shuffle() {
        for (int shuffle = 0; shuffle < (antal / 2); shuffle++) {

            int i = (int) (1 + Math.random() * (antal - 1));
            int j = (int) (1 + Math.random() * (antal - 1));
            Cards temp = deck[i];
            deck[i] = deck[j];
            deck[j] = temp;
        }
        return deck;

    }

    public Deck deal() {
        Deck a = new Deck();
        for (int i = 0; i < 7; i++) {
            a.deck[i] = this.deck[this.antal - 1];
            this.deck[this.antal - 1] = null;
            this.antal = this.antal - 1;
            a.antal++;
        }
        return a;
    }


        public Cards pickCard () {
            Cards card = deck[antal - 1];
            if (antal > 0) {
                antal = antal - 1;
            } else {
                System.out.println("Högen är slut!");
                System.exit(0);
            }
            return card;
        }
}

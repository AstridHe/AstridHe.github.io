import java.util.Arrays;
import java.util.Scanner;

public class Game {




    public static Cards playersMove(Player p, Cards topCard, Deck kortlek){
     while (true) {
         Scanner sc = new Scanner(System.in);
         String input = sc.nextLine();
         try {
             int in = Integer.parseInt(input);
             Cards fromPlayer = p.hand.deck[in - 1];
             for(int i=in-1; i<p.hand.antal; i++) {
                 p.hand.deck[i]=p.hand.deck[i+1];
             }
             p.hand.antal--;
             //System.out.println(fromPlayer);

             if (fromPlayer.colour != topCard.colour && fromPlayer.value != topCard.value) {
                 System.out.println("Du fuskar! Prova med ett annat kort, eller ta upp kort från högen!");
             } else {
                 return p.hand.deck[in - 1];
             }
         } catch (IllegalArgumentException e) {
             if (input.equalsIgnoreCase("Ta upp")) {
                 p.hand.deck[p.hand.antal] = kortlek.pickCard();
             }
             System.out.println(Arrays.toString(p.hand.deck) + " Vilket kort vill du lägga, räknat från vänster?"
                     + "Behöver du ta upp ett kort istället, ange Ta kort.");
         }
     }
    }

    public static Cards computerMove(Player computer, Cards topCard, Deck kortlek ) {
        Cards fromComputer=null;
        boolean noCard = true;
        for (int i = 0; i < computer.hand.antal; i++) {
            if (computer.hand.deck[i].colour == topCard.colour) {
                fromComputer = computer.hand.deck[i];
                for (int j = i; i < computer.hand.antal; j++) {
                    computer.hand.deck[j] = computer.hand.deck[j + 1];
                }
                computer.hand.antal--;
                return fromComputer;

            }
        }
        for (int i = 0; i < computer.hand.antal; i++) {
            if (computer.hand.deck[i].value == 8) {
                fromComputer = computer.hand.deck[i];
                for (int j = i; i < computer.hand.antal; j++) {
                    computer.hand.deck[j] = computer.hand.deck[j + 1];
                }
                computer.hand.antal--;
                return fromComputer;
            }
        }
        while (noCard) {
            Cards kort = kortlek.pickCard();
            if (kort.colour == topCard.colour || kort.value == 8) {
                fromComputer = kort;
                noCard = false;
            } else {
                computer.hand.deck[computer.hand.antal] = kort;
                computer.hand.antal++;
            }

        }  return fromComputer;
    }
    }
 //if (computer.hand.deck[i].value == 8)
   //      System.out.println("Välj färg ");
  //       fromComputer2=computer.hand.deck[(int)(Math.random()*(computer.hand.antal-1)+1)];
    //     break;
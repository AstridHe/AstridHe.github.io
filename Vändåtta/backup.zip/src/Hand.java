//public class Hand {
//    Cards[] cardArray=new Cards[7];
//  int antal;
//
//  public static Hand deal(Deck d){
//      Deck hand=new Deck();
//      for (int i = 0; i <7 ; i++) {
//          hand1.cardArray[i]=d.deck[d.antal-1];
//          d.deck[d.antal-1]=null;
//          d.antal=d.antal-1;
//          hand1.antal++;
//      }return hand1;
//}

import java.io.IOException;
import java.util.NoSuchElementException;
import java.util.Scanner;


public class Main {
    /**
     * Main-metoden för kortspelet, med huvuduppgift att anropa spelets metoder.
     * @param args används ej
     * @throws IOException
     * @throws ClassNotFoundException
     * @throws NoSuchElementException
     */
    public static void main(String[] args) throws IOException, ClassNotFoundException, NoSuchElementException {
        Registration lista = List.read("register.data");
        Player player = Start.welcome(lista);
        Game.startGame(player);

        while (true) {
            System.out.println("Du ger genom att skriva in siffran på det kort du vill lägga, \n" +
                    "eller skriver 'ta upp' om du inte kan. Spelarna får ta upp maximalt 3 kort på ett drag,\n " +
                    "sedan går turen över till motståndaren.\n" +
                    "Regler: Den som blir av med sina kort först vinner. Du får lägga valfritt kort i samma färg, " +
                    "eller ett kort av samma valör som det senast utlagda.");
            Deck kort = new Deck();                                 //Skapar och blandar en kortlek
            kort = kort.createFullDeck();
            kort.shuffle();

            player.hand = Deck.deal(kort);                      //Delar ut kort till spelarna
            Deck computer = Deck.deal(kort);

            Card topCard = kort.pickCard();                     //Lägger ut ett första kort
            System.out.println();
            System.out.println("Startkortet är: " + topCard);
            int turer = 0;
            while (player.hand.getAntal() > 0 && computer.getAntal() > 0) { //Spelet börjar
                if (turer > 52)
                    break;
                System.out.print("Vad lägger du? Dina kort är:");
                Deck.print(player.hand);
                System.out.println();
                Card temp;
                temp = topCard;
                topCard = Game.playersMove(player.hand, topCard, kort);
                if (temp.equals(topCard)) {
                    System.out.println("Datorns tur igen.");
                } else {
                    System.out.print("Du har lagt: ");
                    System.out.println(topCard);
                    turer++;
                }
                //Datorns tur
                temp = topCard;
                topCard = Game.computerMove(computer, topCard, kort);
                if (temp.equals(topCard)) {
                    System.out.println("Datorn kan inte lägga!");
                }
                System.out.println("Senast lagt: ");
                System.out.println(topCard);
                if (temp != topCard)
                    turer++;
            }
            Game.winner(player, computer);

            System.out.println("Skriv 1 för att spela igen");
            Scanner scanner = new Scanner(System.in);
            int i;
            try {
                i = scanner.nextInt();
                if (i != 1) {
                    break;
                }
            } catch (IllegalArgumentException e) {
                break;
            }

        }

        List.skriv(lista);
        Registration t = List.read("register.data");
        //for (Player p:t.data) {
        //   System.out.println("Medlemsnr: "+p.getMEMBER_NUMBER()+". "+p.getName());}
    }
}

import java.io.Serializable;

public class Player implements Serializable{

    private String name;
    Deck hand;
    private int games;
    private int wins;
    private final int MEMBER_NUMBER;
    private static int nextNumber=1;

    //public Player(){
     //    MEMBER_NUMBER = getNextNumber();
    //}
    public Player(String name){
        if(name!=null)
            this.name=name;
       MEMBER_NUMBER=getNextNumber();
    }




    public String getName(){
        return name;
    }
    public int getGames(){
        return games;
    }
    public int getWins() {
        return wins;
    }
    public int getMEMBER_NUMBER(){
    return MEMBER_NUMBER;
    }

    public void setGames(){
        games++;
    }
    public void setWins(){
        wins++;
    }

    public static int getNextNumber(){
        int id=nextNumber;
        nextNumber++;
        return id;

    }


    public String toString(Player p) {
        return p.name +" \nAntal spelade spel: " +p.games + "\nAntal vunna spel: "+p.wins;
    }

}


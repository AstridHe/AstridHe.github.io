import java.io.Serializable;

public class Deck implements Serializable {

    private Card[] deck = new Card[52];
    private int antal;

    public Card[] getdeck() {
        return deck;
    }

    public int getantal() {
        return antal;
    }

    public void plusAntal() {
        antal++;
    }

    public void minusAntal() {
        antal--;
    }

    public Deck createFullDeck() {
        Deck d = new Deck();
        for (int colour = Card.CLOVES, i = 0; colour <= Card.SPADES; colour++) {
            for (int value = 2; value <= 14; value++, i++) {
                d.deck[i] = new Card();
                d.deck[i].colour = colour;
                d.deck[i].value = value;
                d.antal++;
            }
        }
        return d;
    }

    public void shuffle() {
        for (int shuffle = 0; shuffle < (antal); shuffle++) {

            int i = (int) (1 + Math.random() * (antal - 1));
            int j = (int) (1 + Math.random() * (antal - 1));
            Card temp = deck[i];
            deck[i] = deck[j];
            deck[j] = temp;
        }
    }

    public static Deck deal(Deck d) throws NullPointerException {
        Deck a = new Deck();
        for (int i = 0; i < 7; i++) {
            a.deck[i] = d.deck[d.antal - 1];
            d.deck[d.antal - 1] = null;
            d.antal--;
            a.antal++;
        }
        return a;
    }


    public Card pickCard() {
        Card card;
        card = deck[antal - 1];
        antal--;
        return card;

    }

    public static void print(Deck a) {

        for (int i = 0; i < a.antal; i++) {
            System.out.print((i + 1) + ". ");
            System.out.print(a.deck[i] + "\t");
        }
    }
}

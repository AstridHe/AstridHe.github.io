import java.io.*;

public class Test {

    public static void skriv(Registration lista) throws IOException {

        ObjectOutputStream ut = new ObjectOutputStream(new FileOutputStream("register.data"));
        for (int i=0; i<=lista.getNumber(); i++)
              {
                  ut.writeObject(lista.data[i]);
              }
        ut.close();
    }

    public static void skriv() throws IOException {
        Player p0 = new Player("Astrid");
        Player p1 = new Player("Batman");
        Player p2 = new Player("Johan");
        Player p3 = new Player("Iris");
        ObjectOutputStream ut = new ObjectOutputStream(new FileOutputStream("register.data"));
        ut.writeObject(p0);
        ut.writeObject(p1);
        ut.writeObject(p2);
        ut.writeObject(p3);
        ut.close();
    }


    public static Registration läs(String filename) throws IOException {
        ObjectInputStream in = new ObjectInputStream(new FileInputStream(filename));
        Player p = null;
        Registration lista=new Registration();
        int i=0;
        while (true) {
            try {
                p = (Player) in.readObject();
            } catch (ClassNotFoundException e) {
            }catch (EOFException e){
                break;
            }
            if(p != null) {
                System.out.println(p.getName());
            }
            lista.data[i]=p;
            i++;
            lista.setNumber(i);
        }
        in.close();return lista;
    }
}





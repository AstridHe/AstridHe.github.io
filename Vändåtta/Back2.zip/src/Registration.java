import java.io.*;
import java.util.Scanner;


public class Registration {
 public Player[] data=new Player[20];
 private int number=0;

 public void setNumber (int nr) {
     if (nr >= 0)
         number = nr;
     else {
         throw new IllegalArgumentException();
     }
 }
     public int getNumber(){
     return number;
 }

    /**
     * Metod som läser in objekt från en fil
     * @param filename
     * @throws IOException
     * @throws ClassNotFoundException
     */
    public static Registration read(String filename) throws IOException, ClassNotFoundException {
       Registration players =new Registration();
        players.number = 0;

        ObjectInputStream objIn = new ObjectInputStream(
                new FileInputStream(filename));
        Player p;
        while (true) {
            try { players.data = (Player[])objIn.readObject();
            } catch (EOFException e) {
                break;
            }
           // players.data[players.number]=new Player(p.getName(), p.getWins(), p.getGames(), p.getMEMBER_NUMBER());

            System.out.println(players.data[players.number].getName() + "\tnr: "+
                    //+players.data[players.number].getMEMBER_NUMBER() +
                    "\n Antal spelomgångar: " + players.data[players.number].getGames()
                    + " varav vinster: " + players.data[players.number].getWins());
            players.number++;
        }objIn.close();
        return players;
    }

    public static Player findPlayer(String name) throws IOException, ClassNotFoundException {
        ObjectInputStream objIn = new ObjectInputStream(
                new FileInputStream("register.data"));
        Player player=null;
        while (true) {
            try {
                player = (Player) objIn.readObject();
            } catch (EOFException e) {
                break;
            }
           if (player.getName().equals(name)){
                break;
             }
        }
        objIn.close();
        return player;
    }

        public static void write(Player[] arr) throws IOException {
        ObjectOutputStream objOut=new ObjectOutputStream(
                new FileOutputStream("register.data"));
        for (Player person:arr) {
            objOut.writeObject(person);
        }
        objOut.close();
    }

    public static Player welcome() {
        Player player = null;
        System.out.println("Välkommen!\nVad vill du göra?");
        System.out.println("1.Spela!\n" +
                "2. Avsluta programmet");
        Scanner scanner = new Scanner(System.in);
        try {
            int nr = scanner.nextInt();
            if (nr == 1)
                player = login();
            else if (nr == 2)
                System.exit(0);
        } catch (IOException | ClassNotFoundException ex) {
            ex.printStackTrace();
        }
        return player;
    }

    private static Player login() throws IOException, ClassNotFoundException {
        Player player = null;
        System.out.println("För att logga in med användarnamn, tryck 1,\n" +
                "För att registrera nytt, tryck 2");
        Scanner sc = new Scanner(System.in);
        try {
            int nr = sc.nextInt();
            if (nr == 1)
                player = oldUser();
            if (nr == 2)
                player = newUser();
        }catch(IllegalArgumentException e){
            System.out.println("Välj 1 eller 2!");
        }
        return player;

    }

    private static Player oldUser() throws IOException, ClassNotFoundException {
        System.out.println("Välkommen! Skriv in ditt användarnamn:");
        Scanner scanner = new Scanner(System.in);
        String s = scanner.nextLine().trim();
        return Registration.findPlayer(s);

    }

    public static Player newUser() throws IOException, ClassNotFoundException {

        Scanner scanner = new Scanner(System.in);
        System.out.println("Skriv in önskat användarnamn (Endast bokstäver)");
        String s = scanner.nextLine().trim();
        return new Player(s);
    }
}


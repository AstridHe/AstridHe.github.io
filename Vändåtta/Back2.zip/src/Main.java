import java.io.IOException;
import java.util.Arrays;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) throws IOException, ClassNotFoundException {
     //   Registration players=Registration.read("register.data"); // TODO: 2019-12-06 Funkar det med fler än den nyaste???

        Test.skriv();
        Registration lista=Test.läs("register.data");
        Player p=new Player("Tomten");
        lista.data[lista.getNumber()]=p;
        Test.skriv(lista);
        Test.läs("register.data");
        Player player = Start.welcome();
        Game.startGame(player);

        while (true) {
            System.out.println("Du ger genom att skriva in siffran på det kort du vill lägga, \n" +
                    "eller skriver 'ta upp' om du inte kan. Spelarna får ta upp maximalt 3 kort på ett drag,\n " +
                    "sedan går turen över till motståndaren.\n" +
                    "Regler: Den som blir av med sina kort först vinner. Du får lägga valfritt kort i samma färg, " +
                    "eller ett kort av samma valör som det senast utlagda.");
            Deck kort = new Deck();                                 //Skapar och blandar en kortlek
            kort=kort.createFullDeck();
            kort.shuffle();

            player.hand = Deck.deal(kort);                      //Delar ut kort till spelarna
            Deck computer = Deck.deal(kort);

            Card topCard = kort.pickCard();                     //Lägger ut ett första kort
            System.out.println();
            System.out.println("Startkortet är: " + topCard);
// TODO: 2019-12-06 Kontrollera om getantal har någon betydelse, annars ta bort
            while (player.hand.getantal() > 0 && computer.getantal() > 0 && kort.getantal()>=-1) { //Spelet börjar
                System.out.print("Vad lägger du? Dina kort är:");
                Deck.print(player.hand);
                System.out.println();
                Card temp;
                temp = topCard;
                topCard = Game.playersMove(player.hand, topCard, kort);
                if (temp.equals(topCard)) {
                    System.out.println("Datorns tur igen.");
                } else {
                    System.out.print("Du har lagt: ");
                    System.out.println(topCard);
                }
                //Datorns tur
                temp = topCard;
                topCard = Game.computerMove(computer, topCard, kort);
                if (temp.equals(topCard)) {
                    System.out.println("Din tur igen!");
                }
                System.out.println("Senast lagt: ");
                System.out.println(topCard);
            }
            Game.winner(player, computer);

            player.setGames();

            System.out.println("Skriv 1 för att spela igen");
            Scanner scanner=new Scanner(System.in);
            int i;
            try {
                i=scanner.nextInt();
                if(i!=1)
                    break;
            }
            catch (IllegalArgumentException e){
                break;
            }

        }

        //Registration.write(players.data); // TODO: 2019-12-06 Funkar det med fler än den nyaste???
    }
}

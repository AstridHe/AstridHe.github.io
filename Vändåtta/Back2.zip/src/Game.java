import java.io.IOException;
import java.util.Scanner;

public class Game {

    public static void startGame(Player player) throws IOException, ClassNotFoundException {
        if(player!=null)
        System.out.println("Välkommen " + player.getName());
        else{
            System.out.println("Ditt navändarnamn kunde inte hittas, vänligen registrera dig:");
            player=Registration.newUser();
        System.out.println("Välkommen " + player.getName());}


    }
       public static void winner(Player player, Deck computer) {
           if (player.hand.getantal() == 0 && computer.getantal() == 0)
               System.out.println("Ni kom lika!");
           else if (player.hand.getantal() == 0) {
               System.out.println("Grattis, du vann!");
               player.setWins();
           } else if(computer.getantal()==0){
               System.out.println("Vinst till datorn!");
           }
           else
               System.out.println("Oavgjort, spelet går inte ut!");
       }

    static Card playersMove(Deck d, Card topCard, Deck kortlek) {
        for (int i = 0; i < 3; i++) {
            Scanner sc = new Scanner(System.in);
            String input = sc.nextLine();
            try {
                int in = Integer.parseInt(input);
                if (in <= d.getantal() && in > 0) {
                    Card fromPlayer = d.getdeck()[in - 1];
                    if (fromPlayer.colour != topCard.colour && fromPlayer.value != topCard.value) {
                        System.out.println("Du fuskar! Prova med ett annat kort, eller ta upp kort från högen!");
                    } else {
                        for (i = in - 1; i < d.getantal(); i++)
                            d.getdeck()[i] = d.getdeck()[i + 1];
                        d.minusAntal();
                        return fromPlayer;
                    }
                } else
                    System.out.println("Ogiltig siffra, försök igen!");
            } catch (IllegalArgumentException e) {
                if (input.equalsIgnoreCase("Ta upp")) {
                    if (kortlek.getantal()>0){
                    d.getdeck()[d.getantal()] = kortlek.pickCard();
                    d.plusAntal();
                    Deck.print(d);
                    System.out.println();}
                    else {
                        i=3;
                        System.out.println("Kortleken är slut.");
                    }
                } else
                    System.out.println("Ogiltig input!");

            }
        }
        return topCard;
    }

    static Card computerMove(Deck computer, Card topCard, Deck kortlek) throws NullPointerException {

        for (int i = 0; i < computer.getantal(); i++) {
            if (computer.getdeck()[i].colour == topCard.colour || computer.getdeck()[i].value == topCard.value) {
                Card fromComputer = computer.getdeck()[i];
                for (int j = i; j < computer.getantal(); j++) {
                    computer.getdeck()[j] = computer.getdeck()[j + 1];
                }
                computer.minusAntal();
                return fromComputer;
            }
        }
        for (int i = 0; i < 3; i++) {
            if (kortlek.getantal() > 0) {
                Card kort = kortlek.pickCard();
                    if (kort.colour == topCard.colour || kort.value == topCard.value) {
                        return kort;
                    } else {
                        computer.getdeck()[computer.getantal()] = kort;
                        computer.plusAntal();
                    }
                }else{
                    i=3;
                    System.out.println("Högen är slut!");
                }

        }return topCard; //Returnerar det senast lagda kortet om inget nytt lagts
    }
}

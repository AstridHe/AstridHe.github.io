import java.io.Serializable;

public class Card implements Serializable {
    int colour;
    int value;
    public static final int CLOVES = 0;
    public static final int DIAMOND = 1;
    public static final int HEARTS = 2;
    public static final int SPADES = 3;
    private static final String[] NAMN = {"Klöver", "Ruter", "Hjärter", "Spader"};
    private static final String[] NR = {"två", "tre", "fyra", "fem", "sex", "sju", "åtta", "nio", "tio", "knekt", "dam", "kung", "ess"};


    @Override
    public String toString() {
          return NAMN[colour] + " " + NR[value - 2];
    }

}

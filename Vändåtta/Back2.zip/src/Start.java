import java.io.IOException;
import java.util.InputMismatchException;
import java.util.Scanner;

public class Start {

    public static Player welcome() {
        Player player = null;
        System.out.println("Välkommen!\nVad vill du göra?");
        System.out.println("1.Spela!\n" +
                "2. Avsluta programmet");
        Scanner scanner = new Scanner(System.in);
        try {
            int nr = scanner.nextInt();
            if (nr == 1)
                player = login();
            else if (nr == 2)
                System.exit(0);
        } catch (IOException | ClassNotFoundException ex) {
            ex.printStackTrace();
        }
        return player;
    }

    private static Player login() throws IOException, ClassNotFoundException, IllegalArgumentException {
        Player player = null;
        System.out.println("För att logga in med användarnamn, tryck 1,\n" +
                "För att registrera nytt, tryck 2");
        Scanner sc = new Scanner(System.in);
       try{ int nr = sc.nextInt();
        if (nr == 1)
            player = oldUser();
        if (nr == 2)
            player = newUser();
       }catch (InputMismatchException e){
           System.out.println("Skriv 1 eller 2!");
       }
        return player;

    }

    private static Player oldUser() throws IOException, ClassNotFoundException {
        System.out.println("Välkommen! Skriv in ditt användarnamn:");
        Scanner scanner = new Scanner(System.in);
        String s = scanner.nextLine().trim();
        return Registration.findPlayer(s);

    }

    private static Player newUser() throws IOException, ClassNotFoundException {

        Scanner scanner = new Scanner(System.in);
        System.out.println("Skriv in önskat användarnamn (Endast bokstäver)");
        String s = scanner.nextLine().trim();
        return new Player(s);
    }
}

